package com.wallet.service;

import com.wallet.model.AmountTransaction;
import com.wallet.model.User;
import com.wallet.model.UserDetails;

public interface ServiceMethods {

	public User createAccount(UserDetails u); 
}
