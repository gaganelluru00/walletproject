package com.wallet.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;

import com.wallet.dao.TransactionRepository;
import com.wallet.dao.UserRepository;
import com.wallet.model.AmountTransaction;
import com.wallet.model.User;
import com.wallet.model.UserDetails;

public class ServiceMethodsImpl implements ServiceMethods {

	@Autowired
	UserRepository uRepo;
	@Autowired
	TransactionRepository tRepo;
	User user=null;
	public User createAccount(UserDetails u) {
		int c=uRepo.countByUsername(u.getUsername());
		int uId=uRepo.countByUserId(Long.parseLong(u.getUserId()));
		
		 if(c>=1||uId>=1) {
			return null;
		}
		
		else {
		LocalDateTime t=LocalDateTime.now();
		String accTime=t.toString();
		
		String acc="ACC"+User.accNum;
		User.accNum++;
		Long id=Long.parseLong(u.getUserId());
		user=new User(id,u.getEmail(),u.getMobile(),0,accTime,u.getAccountType(),acc,u.getUsername(),u.getPassword());
		uRepo.save(user);
		return user;
		}
		
	}
	
}
