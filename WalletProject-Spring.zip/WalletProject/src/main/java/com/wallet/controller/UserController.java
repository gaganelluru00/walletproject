package com.wallet.controller;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.wallet.dao.TransactionRepository;
import com.wallet.dao.UserRepository;
import com.wallet.model.AmountTransaction;
import com.wallet.model.Transaction;
import com.wallet.model.User;
import com.wallet.model.UserDetails;
import com.wallet.service.ServiceMethods;
import com.wallet.service.ServiceMethodsImpl;

@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/transfer")
public class UserController {
	@Autowired
	private UserRepository uRepo;
	@Autowired
	private TransactionRepository tRepo;
	User user=null;
	User rec=null;
	User userIncorrect=new User();
	Transaction trans=null;
	Transaction trans1=null;
	ArrayList<User> users=null;
	List<Transaction> transactions=null;
	

	@PostMapping("/add")
	public User createUserAccount(@RequestBody UserDetails u) {
		
		int c=uRepo.countByUsername(u.getUsername());
		int uId=uRepo.countByUserId(Long.parseLong(u.getUserId()));
		
		
		if(c>=1||uId>=1) {
			return null;
		}
		
		else {
		LocalDateTime t=LocalDateTime.now();
		String accTime=t.toString();
		
		String acc="ACC"+User.accNum;
		User.accNum++;
		Long id=Long.parseLong(u.getUserId());
		user=new User(id,u.getEmail(),u.getMobile(),0,accTime,u.getAccountType(),acc,u.getUsername(),u.getPassword());
		uRepo.save(user);
		return user;
		}
	}
	
	@PostMapping("/deposit")
	public User depositAmount(@RequestBody AmountTransaction at) {
		
		int login=uRepo.countByUsernameAndPassword(at.getUsername(), at.getPassword());
		if(login==0) {
			userIncorrect.setUsername("Incorrect Username or Password");
			return userIncorrect;
		}
		else {
		LocalDateTime time=LocalDateTime.now();
		String stime=time.toString();
		String transId="TX"+stime;
		String type="Deposit";
		double transAmount=Double.parseDouble(at.getAmount());
		user=uRepo.findByUsernameAndPassword(at.getUsername(), at.getPassword());
		Long id=user.getUserId();
		
		double balance=user.getAccountBalance();
		balance=balance+Double.parseDouble(at.getAmount());
		String acc=user.getAccountNumber();
		trans=new Transaction(id,transId,stime,type,acc,null,Double.parseDouble(at.getAmount()),balance);
		//uRepo.delete(user);
		tRepo.save(trans);
		
		String ctime=user.getTime();
		uRepo.delete(user);
		user.setTime(ctime);
		user.setAccountBalance(balance);
		uRepo.save(user);
		//uRepo.updateBalance(balance, at.getUsername(), at.getPassword());
		//uRepo.updateBalance(balance, at.getUsername(), at.getPassword());
		
		return user;}
	}
	@PostMapping("/withdraw")
	public User withdrawAmount(@RequestBody AmountTransaction at) {
		int login=uRepo.countByUsernameAndPassword(at.getUsername(), at.getPassword());
		if(login==0){
			userIncorrect.setUsername("Incorrect Username or Password");
			return userIncorrect;
		}
		user=uRepo.findByUsernameAndPassword(at.getUsername(), at.getPassword());
		Long id=user.getUserId();
		double balance=user.getAccountBalance();
		if(balance<=Double.parseDouble(at.getAmount())) {
			return null;
		}
		
		
		else {
			balance=balance-Double.parseDouble(at.getAmount());
		LocalDateTime time=LocalDateTime.now();
		String stime=time.toString();
		String transId="TX"+stime;
		String type="Withdraw";
		double transAmount=Double.parseDouble(at.getAmount());
		
		String acc=user.getAccountNumber();
		
		trans=new Transaction(id,transId,stime,type,acc,null,Double.parseDouble(at.getAmount()),balance);
		//uRepo.delete(user);
		tRepo.save(trans);
		
		String ctime=user.getTime();
		uRepo.delete(user);
		user.setTime(ctime);
		user.setAccountBalance(balance);
		uRepo.save(user);
		//uRepo.updateBalance(balance, at.getUsername(), at.getPassword());
		
		return user;
		}
		
	}
	@PostMapping("/fund")
	public User fundTransfer(@RequestBody AmountTransaction at) {
		
		int login=uRepo.countByUsernameAndPassword(at.getUsername(), at.getPassword());
		int acount=uRepo.countByAccountNumber(at.getAccNumber());
		if(login==0){
			userIncorrect.setUsername("Incorrect Username or Password");
			return userIncorrect;
		}
		/*if(acount==0) {
			userIncorrect=null;
			userIncorrect.setAccountNumber("Incorrect account number");
			return userIncorrect;
		}*/
		LocalDateTime time=LocalDateTime.now();
		String stime=time.toString();
		String transId="TX"+stime;
		String type="Fund Transfered";
		String type1="Fund Received";
		user=uRepo.findByUsernameAndPassword(at.getUsername(), at.getPassword());
		double balance=user.getAccountBalance();
		double transAmount=Double.parseDouble(at.getAmount());
		if(balance<=transAmount) {
			return null;
		}
		else {
		
		balance=balance-Double.parseDouble(at.getAmount());
		Long id=user.getUserId();
		String acc=user.getAccountNumber();
		String ctime=user.getTime();
		uRepo.delete(user);
		user.setTime(ctime);
		user.setAccountBalance(balance);
		uRepo.save(user);
		
		
		
		
		String accN=at.getAccNumber();
		rec=uRepo.findByAccountNumber(accN);
		double balance1=rec.getAccountBalance();
		balance1=balance1+Double.parseDouble(at.getAmount());
		Long id1=rec.getUserId();
		String ctime1=rec.getTime();
		uRepo.delete(rec);
		rec.setTime(ctime1);
		rec.setAccountBalance(balance1);
		uRepo.save(rec);
		
		trans=new Transaction(id,transId,stime,type,acc,accN,Double.parseDouble(at.getAmount()),balance);
		tRepo.save(trans);
		trans1=new Transaction(id1,transId,stime,type1,accN,acc,Double.parseDouble(at.getAmount()),balance1);
		tRepo.save(trans1);
		return user;
		}
	}
	@PostMapping("/show")
	public User showBalance(@RequestBody AmountTransaction at) {
		int login=uRepo.countByUsernameAndPassword(at.getUsername(), at.getPassword());
		if(login==0){
			userIncorrect.setUsername("Incorrect Username or Password");
			return userIncorrect;
		}
		else {
		user=uRepo.findByUsernameAndPassword(at.getUsername(), at.getPassword());
		//userPass=user;
		return user;
		}
	}
	/*@GetMapping(value="/show",produces="application/json")
	public User sendBalance() {
		return userPass;
	}*/
	@PostMapping("/login")
	public User loginValidation(@RequestBody AmountTransaction at) {
		int count=uRepo.countByUsernameAndPasswordAndAccountNumber(at.getUsername(), at.getPassword(), at.getAccNumber());
		if(count>0) {
			user=uRepo.findByUsernameAndPasswordAndAccountNumber(at.getUsername(), at.getPassword(), at.getAccNumber());
			return user;
		}
		else {
		return null;}
	}
	@PostMapping("/print")
public List<Transaction> sendTransactions(@RequestBody AmountTransaction at) {
		int c=uRepo.countByAccountNumberAndPassword( at.getAccNumber(),at.getPassword());
		if(c==0) {
			return null;
		}
		else {
		user=uRepo.findByAccountNumberAndPassword(at.getAccNumber(), at.getPassword());
		transactions=tRepo.findByRecId(user.getAccountNumber());
		
		return transactions;
		
		}
	}
	
}
