import { Component, OnInit } from '@angular/core';
import { AmountTransaction, HttpclientService,User } from '../service/httpclient.service';
import {Router} from '@angular/router';
@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  public username:String;
  public password:String;
  public accNumber:String;
  public amount:String;
  fundT:AmountTransaction=new AmountTransaction("","","","");
  user:User=new User("","","",0,"","","","","");
  constructor(private httpclientService:HttpclientService,private rou:Router) { }

  ngOnInit(): void {
  }
  fundTransferAmt():void{
    this.fundT.username=this.httpclientService.use.username;
    this.fundT.password=this.httpclientService.use.password;
    this.httpclientService.fundTransfer(this.fundT).subscribe( data => {this.getTransfer(data);
      if(data){
        if(this.user.username=="Incorrect Username or Password")
        {
          alert("Incorrect Username or Password");
        }
        else if(this.user.accountNumber=="Incorrect account number"){
          alert("Account number for fund transfer doesnot exist");
        }
        else{
        alert("Fund Transfer Successful and balance is "+this.user.accountBalance);}
      }
      else{
        alert("Insufficient Balance");
      }
    });

};
getTransfer(data){
this.user=data;
}
openLogin(){
  this.rou.navigate(['transfer/login']);
}
openWithdraw(){
  this.rou.navigate(['transfer/withdraw']);
}
openDeposit(){
  this.rou.navigate(['transfer/deposit']);
}
openFund(){
  this.rou.navigate(['transfer/fund']);
}
openBalance(){
  this.rou.navigate(['transfer/show']);
}
openTransaction(){
  this.rou.navigate(['transfer/print']);
}


}
