import { Component, OnInit } from '@angular/core';
import { AmountTransaction, HttpclientService,User} from '../service/httpclient.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {
public username:String;
public password:String;
public accNumber:String;
public amount:String;
dep:AmountTransaction=new AmountTransaction("","","","");
user:User=new User("","","",0,"","","","","");


  constructor(private httpclientService:HttpclientService,private rou:Router) { }

onDeposit(value:any){}

  ngOnInit(): void {
  }
  
  depositAmount():void{
    this.dep.username=this.httpclientService.use.username;
    this.dep.password=this.httpclientService.use.password;
    this.httpclientService.depositAmount(this.dep).subscribe( data => {this.getStatus(data);
      if(this.user.username=="Incorrect Username or Password")
      {alert("Incorrect Username or Password");}
      else{
      alert("Amount deposited in the account");}
    });
    this.rou.navigate(['transfer/fund']);

};

getStatus(data){
  this.user=data;
}
openLogin(){
  this.rou.navigate(['transfer/login']);
}
openWithdraw(){
  this.rou.navigate(['transfer/withdraw']);
}
openDeposit(){
  this.rou.navigate(['transfer/deposit']);
}
openFund(){
  this.rou.navigate(['transfer/fund']);
}
openBalance(){
  this.rou.navigate(['transfer/show']);
}
openTransaction(){
  this.rou.navigate(['transfer/print']);
}
openHome(){
  this.rou.navigate(['transfer/home']);
}


}
