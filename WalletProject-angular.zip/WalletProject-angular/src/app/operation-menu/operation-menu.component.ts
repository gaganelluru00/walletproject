import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-operation-menu',
  templateUrl: './operation-menu.component.html',
  styleUrls: ['./operation-menu.component.css']
})
export class OperationMenuComponent implements OnInit {

  constructor(private rou:Router) { }

  ngOnInit(): void {
  }
  openLogin(){
    this.rou.navigate(['transfer/login']);
  }
  openWithdraw(){
    this.rou.navigate(['transfer/withdraw']);
  }
  openDeposit(){
    this.rou.navigate(['transfer/deposit']);
  }
  openFund(){
    this.rou.navigate(['transfer/fund']);
  }
  openBalance(){
    this.rou.navigate(['transfer/show']);
  }
  openTransaction(){
    this.rou.navigate(['transfer/print']);
  }
  
  
  }
  
